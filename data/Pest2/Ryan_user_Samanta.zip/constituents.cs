constituents.cs: written by SWAT+ editor v2.3.1 on 2023-08-15 15:10 for SWAT+ rev.60.5.7
     2                !pesticides       
        dacamine roundup 
     0                !pathogens        
        
     0                !metals           
        
     0                !salts            
        
